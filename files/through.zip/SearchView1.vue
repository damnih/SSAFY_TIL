
<template>
  <div>
    <h2>유튜브 검색</h2>
    <!-- 1. 검색어 입력 -->
    <input
      v-model="searchWhat"
      @keyup.enter="onSearch"
      placeholder="검색어를 입력하고 Enter"
    />
    <button @click="onSearch">검색</button>

    <!-- 2. 로딩/에러 표시 -->
    <p v-if="loading">로딩 중…</p>
    <p v-if="error" style="color: red">에러: {{ error.message }}</p>

    <!-- 3. 결과 리스트 -->
    <ul v-if="videos.length">
      <li v-for="video in videos" :key="video.id.videoId">
        <!-- name 과 params.videoId 를 일치시켜 줍니다 -->
        <router-link 
          :to="{ name: 'videoDetail', params: { videoId: video.id.videoId } }"
        >
          <img 
            :src="video.snippet.thumbnails.default.url" 
            alt="thumbnail" 
          />
          {{ video.snippet.title }}
        </router-link>
      </li>
    </ul>
    <p v-else-if="!loading">검색 결과가 없습니다.</p>
  </div>
</template>

<script setup>

  import { ref, onMounted } from 'vue'
  import axios from 'axios'

// 1) 반응형 상태 선언
  const searchWhat = ref('')        // 사용자가 입력한 검색어
  const videos     = ref([])        // API에서 받은 결과 리스트
  const loading    = ref(false)     // 로딩 상태
  const error      = ref(null)      // 에러 객체

// 2) 검색 실행 함수
  async function onSearch() {
    if (!searchWhat.value.trim()) 
      return
      loading.value = true
      error.value   = null
    try {
      const { data } = await axios.get(
        'https://www.googleapis.com/youtube/v3/search',
        {
          params: {
            part:       'snippet',
            // q:          searchWhat.value,
            // 위가 기존 코드 아래가 바꾼 코드 
            q:          'Vue.js',
            type:       'video',
            maxResults: 10,
            key:        import.meta.env.VITE_YOUTUBE_API_KEY
          }
        }
      )
      videos.value = data.items
    } catch (e) {
      error.value = e
    } finally {
      loading.value = false
    }
  }

// (선택) 컴포넌트가 처음 마운트될 때 기본 검색
// import { onMounted } from 'vue'
// onMounted(() => {
//   searchWhat.value = 'Vue.js'
//   onSearch()
// })
</script>

<style scoped>
input {
  padding: 4px 8px;
  margin-right: 4px;
}
button {
  padding: 4px 12px;
}
ul {
  list-style: none;
  padding: 0;
}
li {
  display: flex;
  align-items: center;
  margin: 8px 0;
}
img {
  width: 60px;
  height: 45px;
  margin-right: 8px;
}
</style>
