<template>
  <div class="detail">
    <h1>{{ videoInfo.snippet.title }}</h1>
    <p>업로드: {{ videoInfo.snippet.publishedAt.slice(0,10) }}</p>

    <iframe
      width="560"
      height="315"
      :src="`https://www.youtube.com/embed/${videoId}`"
      frameborder="0"
      allowfullscreen
    ></iframe>

    <p>{{ videoInfo.snippet.description }}</p>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios             from 'axios'

// props로 받은 videoId
const props     = defineProps({ videoId: String })
const videoId   = props.videoId

const videoInfo = ref({ snippet: { title:'', description:'', publishedAt:'' } })

onMounted(async () => {
  try {
    const res = await axios.get(
      'https://www.googleapis.com/youtube/v3/videos',
      {
        params: {
          part: 'snippet',
          id:   videoId,
          key:  import.meta.env.VITE_YOUTUBE_API_KEY
        }
      }
    )
    // items[0]에 상세 정보가 들어 있음
    videoInfo.value = res.data.items[0]
  } catch (e) {
    console.error('상세 정보 로드 실패', e)
  }
})
</script>

<style scoped>
.detail {
  max-width: 800px;
  margin: 2rem auto;
}
iframe {
  display: block;
  margin: 1rem 0;
}
</style>
