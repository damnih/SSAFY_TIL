import { createRouter, createWebHistory } from 'vue-router'
import SearchView  from '../views/SearchView.vue'
import VideoDetail from '../views/VideoDetail.vue'
import SaveView    from '../views/SaveView.vue'

const routes = [
  { 
    path: '/',                
    name: 'Search',      
    component: SearchView 
  },
  {
    path: '/video/:videoId', // 이 아이디는 카멜케이스인거 기억해 
    name: 'VideoDetail',    // ← 대문자 V 와 D
    component: VideoDetail,
    props: true
  },
  {
    path: '/saved',
    name: 'Saved',
    component: SaveView
  },
  
]

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes
})

export default router


