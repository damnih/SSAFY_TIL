<template>
  <nav class="nav-bar">
    <router-link to="/" class="nav-link">Search</router-link>
    <router-link to="/saved" class="nav-link">Saved</router-link>
  </nav>
  <router-view />
</template>

<script setup>
// Router handles view components
</script>

<style scoped>
.nav-bar {
  padding: 1rem;
  background-color: #f5f5f5;
}
.nav-link {
  margin-right: 1rem;
  text-decoration: none;
  color: #333;
}
.nav-link.router-link-active {
  font-weight: bold;
}
</style>

