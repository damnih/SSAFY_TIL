<template>
  <div class="container mt-4">
    <h1 class="mb-4">나중에 볼 동영상</h1>

    <!-- 저장된 게 하나도 없으면 -->
    <p v-if="savedVideos.length === 0">등록된 비디오 없음</p>

    <!-- 하나라도 있으면 카드 형태로 -->
    <div v-else class="row">
      <div
        v-for="video in savedVideoInfos"
        :key="video.id"
        class="col-md-4 mb-4"
      >
        <div class="card h-100">
          <router-link
            :to="{ name: 'VideoDetail', params: { videoId: video.id } }"
            class="text-decoration-none"
          >
            <iframe
              class="card-img-top"
              :src="`https://www.youtube.com/embed/${video.id}`"
              height="170"
              frameborder="0"
              allowfullscreen
            ></iframe>
            <div class="card-body">
              <!-- 여기서 snippet.title 출력 -->
              <p class="card-text text-center">{{ video.snippet.title }}</p>
            </div>
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import axios from 'axios'

const savedVideos     = ref([])  // ID 목록
const savedVideoInfos = ref([])  // API로 받아온 객체 목록

async function loadSavedVideos() {
  // 1) 로컬 스토리지에서 ID 배열 가져오기
  const ids = JSON.parse(localStorage.getItem('savedVideos') || '[]')
  savedVideos.value = ids

  // 2) ID가 하나라도 있으면, videos.list API로 상세 정보 가져오기
  if (ids.length) {
    try {
      const res = await axios.get(
        'https://www.googleapis.com/youtube/v3/videos',
        {
          params: {
            part: 'snippet',
            id:   ids.join(','),                        // "id1,id2,id3"
            key:  import.meta.env.VITE_YOUTUBE_API_KEY
          }
        }
      )
      // items는 [{ id, snippet:{ title, ... } }, ...]
      savedVideoInfos.value = res.data.items
    } catch (e) {
      console.error('저장 동영상 정보 로드 실패', e)
    }
  }
}

onMounted(() => {
  loadSavedVideos()
})
</script>

<style scoped>
/* 필요하다면 부트스트랩/커스텀 스타일 추가 */
</style>
