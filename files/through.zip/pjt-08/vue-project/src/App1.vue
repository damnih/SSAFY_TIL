
<template>
  <div>
    <h1>히이  </h1>
  </div>
  <div>
    <router-view />
  </div>

</template>

<script setup>
  import SearchView from "./views/SearchView.vue";
  import VideoDetail from "./views/VideoDetail2.vue"
</script>

<style  scoped>

</style>