
<template>
  <div class="detail">
    <h1>{{ videoInfo.snippet.title }}</h1>
    <p>업로드: {{ videoInfo.snippet.publishedAt.slice(0,10) }}</p>

    <iframe
      width="560"
      height="315"
      :src="`https://www.youtube.com/embed/${videoId}`"
      frameborder="0"
      allowfullscreen
    ></iframe>

    <p>{{ videoInfo.snippet.description }}</p>

    <button v-if="!isSaved" @click="saveVideo">저장</button>
    <button v-else @click="removeVideo">저장 취소</button>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue'
import { useRoute } from 'vue-router'
import axios from 'axios'

const route    = useRoute()
const videoId  = route.params.videoId

const videoInfo   = ref({ snippet: { title: '', description: '', publishedAt: '' } })
const savedVideos = ref([])

onMounted(() => {
  loadVideo()
  loadSaved()
})

async function loadVideo() {
  try {
    const res = await axios.get(
      'https://www.googleapis.com/youtube/v3/videos',
      { params: { part: 'snippet', id: videoId, key: import.meta.env.VITE_YOUTUBE_API_KEY } }
    )
    videoInfo.value = res.data.items[0]
  } catch (e) {
    console.error('상세 정보 로드 실패', e)
  }
}

function loadSaved() {
  savedVideos.value = JSON.parse(localStorage.getItem('savedVideos') || '[]')
}

const isSaved = computed(() => savedVideos.value.includes(videoId))

function saveVideo() {
  if (!savedVideos.value.includes(videoId)) {
    savedVideos.value.push(videoId)
    localStorage.setItem('savedVideos', JSON.stringify(savedVideos.value))
  }
}

function removeVideo() {
  savedVideos.value = savedVideos.value.filter(id => id !== videoId)
  localStorage.setItem('savedVideos', JSON.stringify(savedVideos.value))
}
</script>

<style scoped>
.detail { max-width: 800px; margin: 2rem auto; }
iframe { display: block; margin: 1rem 0; }
button { margin-top: 1rem; }
</style>