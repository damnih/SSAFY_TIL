<template>
  <div class="container mt-4">
    <h1>나중에 볼 동영상</h1>
    <div v-if="savedVideos.length === 0">
      등록된 비디오 없음
    </div>
    <div v-else class="row">
      <div
        v-for="videoId in savedVideos"
        :key="videoId"
        class="col-md-4 mb-4"
      >
        <div class="card h-100">
          <router-link
            :to="{ name: 'VideoDetail', params: { videoId } }"
            class="text-decoration-none"
          >
            <iframe
              class="card-img-top"
              :src="`https://www.youtube.com/embed/${videoId}`"
              height="170"
              frameborder="0"
              allowfullscreen
            ></iframe>
            <div class="card-body">
              <p class="card-text text-center">동영상 ID: {{ videoId }}</p>
            </div>
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'

const savedVideos = ref([])

onMounted(() => {
  savedVideos.value = JSON.parse(localStorage.getItem('savedVideos') || '[]')
})
</script>

<style scoped>
.container { max-width: 960px; margin: auto; }
.mt-4 { margin-top: 1rem; }
.mb-4 { margin-bottom: 1rem; }
.row { display: flex; flex-wrap: wrap; }
.col-md-4 { width: 33.333%; padding: 0.5rem; }
.card { border: 1px solid #ddd; border-radius: 4px; overflow: hidden; }
.card-img-top { width: 100%; }
.card-body { padding: 0.5rem; }
</style>
