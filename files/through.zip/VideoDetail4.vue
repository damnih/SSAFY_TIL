
<template>
  <div>
    <h1>{{ videos.title }}</h1>
    <p>업로드 날짜: {{ videos.date }}</p>
    
    <iframe
      width="560"
      height="315"
      :src="`https://www.youtube.com/embed/${videoId}`"
      title="YouTube video player"
      frameborder="0"
      allowfullscreen
    ></iframe>

    <p>{{ videos.description }}</p>

    <button @click="toggleSave">
      {{ isSaved ? '저장 취소' : '동영상 저장' }}
    </button>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import SearchView from './SearchView.vue'


const route = useRoute()
// const videoId = route.params.videoId

// 예시: 실제 API 호출 대신 임의의 더미 데이터 사용
// const videos = ref({
//   title: '삼성전자 연중 최고가 갱신... 지금 사야 할까? 팔아야 할까?',
//   date: '2023-03-24',
//   description: '삼성전자에 대한 분석과 전망을 다룬 영상입니다.',
// })

// videoId 는 라우터 params 에서 자동으로 들어옵니다
const props     = defineProps({ videoId: String })
const videoId   = props.videoId

const videos = ref({ title: '', description: '' })

// 로컬 스토리지 확인
const isSaved = ref(false)

const checkSaved = () => {
  const savedVideos = JSON.parse(localStorage.getItem('savedVideos') || '[]')
  isSaved.value = savedVideos.includes(videoId)
}

const toggleSave = () => {
  let savedVideos = JSON.parse(localStorage.getItem('savedVideos') || '[]')
  if (isSaved.value) {
    savedVideos = savedVideos.filter(id => id !== videoId)
  } else {
    savedVideos.push(videoId)
  }
  localStorage.setItem('savedVideos', JSON.stringify(savedVideos))
  isSaved.value = !isSaved.value
}

onMounted(() => {
  checkSaved()
})
</script>

<style></style>