
<template>
  <div>
    <!-- 검색어 입력하는 파트!!!!! -->
    <input
      v-model="search"
      @keyup.enter="onSearch"
      placeholder="검색어 입력 후 Enter 또는 버튼 클릭"
    />
    <button @click="onSearch">검색</button>

    <!-- 로딩 / 에러 -->
    <p v-if="loading">로딩 중…</p>
    <p v-if="error" style="color: red">에러 발생: {{ error.message }}</p>
    <p v-else-if="!loading">검색 결과가 없습니다.</p>

    <!-- 결과 리스트!!!  -->
    <ul v-if="videos.length">
      <li v-for="video in videos" :key="video.id.videoId">
        <router-link
          :to="{ name: 'VideoDetail', params: { videoId: video.id.videoId } }"
        >
          <img
            :src="video.snippet.thumbnails.default.url"
            alt="thumbnail"
          />
          {{ video.snippet.title }}
        </router-link>
      </li>
    </ul>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import axios from 'axios'

const search = ref('')    // ← v-model과 같은 이름인지
const videos     = ref([])    // ← template의 videos와 일치하는지
const loading    = ref(false)
const error      = ref(null)

async function onSearch() {   // ← @click="onSearch"과 같은 이름인지
  if (!search.value.trim()) return

  loading.value = true
  error.value   = null

try {
    const res = await axios.get(
      'https://www.googleapis.com/youtube/v3/search',
      {
        params: {
          part:       'snippet',
          q:          search.value,
          type:       'video',
          maxResults: 10,
          key:        import.meta.env.VITE_YOUTUBE_API_KEY
        }
      }
    )
    videos.value = res.data.items
  } catch (e) {
    error.value = e
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
input {
  padding: 4px 8px;
  margin-right: 4px;
}
button {
  padding: 4px 12px;
}
ul {
  list-style: none;
  padding: 0;
}
li {
  display: flex;
  align-items: center;
  margin: 8px 0;
}
img {
  width: 60px;
  height: 45px;
  margin-right: 8px;
}
</style>
