<template>
  <div class="search-view">
    <!-- 1) 검색어 입력 -->
    <input
      v-model="search"
      @keyup.enter="onSearch"
      placeholder="검색어 입력 후 Enter"
    />
    <button @click="onSearch">검색</button>

    <!-- 2) 상태 표시: 반드시 한 체인으로 묶고, 각 블록에 key -->
    <div v-if="loading" key="loading">
      로딩 중…
    </div>

    <div v-else-if="error" key="error" style="color: red">
      에러 발생: {{ error.message }}
    </div>

    <div v-else key="result">
      <!-- 3) 정상 상태: 결과 리스트 또는 빈 메시지 -->
      <ul v-if="videos.length">
        <li v-for="video in videos" :key="video.id.videoId">
          <router-link
            :to="{ name: 'VideoDetail', params: { videoId: video.id.videoId } }"
          >
            <img
              :src="video.snippet.thumbnails.default.url"
              alt="thumbnail"
            />
            {{ video.snippet.title }}
          </router-link>
        </li>
      </ul>
      <p v-else>검색 결과가 없습니다.</p>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import axios from 'axios'

const search  = ref('')
const videos  = ref([])
const loading = ref(false)
const error   = ref(null)

async function onSearch() {
  if (!search.value.trim()) return

  loading.value = true
  error.value   = null
  videos.value  = []   // 이전 결과 클리어

  try {
    const res = await axios.get(
      'https://www.googleapis.com/youtube/v3/search',
      {
        params: {
          part:       'snippet',
          q:          search.value,
          type:       'video',
          maxResults: 10,
          key:        import.meta.env.VITE_YOUTUBE_API_KEY
        }
      }
    )
    videos.value = res.data.items
    console.log('▶ videos.value:', videos.value)
  } catch (e) {
    console.error('검색 중 에러 응답 바디:', e.response?.data || e)
    error.value = e
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
/* 필요에 따라 스타일 추가 */
</style>
