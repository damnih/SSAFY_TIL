

<template>
  <div class="container mt-4">
    <h1 class="mb-4">나중에 볼 동영상</h1>
    <p v-if="savedVideos.length === 0">등록된 비디오 없음</p>
    <div v-else class="row">
      <div v-for="videoId in savedVideos" :key="videoId" class="col-md-4 mb-4">
        <div class="card h-100">
          <router-link :to="{ name: 'videoDetail', params: { videoId } }" class="text-decoration-none">
            <iframe
              class="card-img-top"
              :src="'https://www.youtube.com/embed/' + videoId"
              height="170"
              frameborder="0"
              allowfullscreen
            ></iframe>
            <div class="card-body">
              <p class="card-text text-center">동영상 ID: {{ videoId }}</p>
            </div>
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>


<script setup>
// 여기에 반드시
  import { ref, onMounted } from 'vue'
  const savedVideos = ref([])
//   // 로컬스토리지에서 불러와서 savedVideos.value에 할당
// 이런 변수를 선언해 주셔야, template에서 savedVideos를 찾을 수 있습니다.
  onMounted(() => {
  savedVideos.value = JSON.parse(
    localStorage.getItem('savedVideos') || '[]'
    )
  })
</script>


<style scoped>

</style>