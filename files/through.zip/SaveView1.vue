<template>
  <div class="container mt-4">
    <h1 class="mb-4">나중에 볼 동영상</h1>
    <p v-if="savedVideos.length === 0">등록된 비디오 없음</p>
    <div v-else class="row">
      <div v-for="videoId in savedVideos" :key="videoId" class="col-md-4 mb-4">
        <div class="card h-100">
          <router-link :to="{ name: 'videoDetail', params: { videoId } }" class="text-decoration-none">
            <iframe
              class="card-img-top"
              :src="'https://www.youtube.com/embed/' + videoId"
              height="170"
              frameborder="0"
              allowfullscreen
            ></iframe>
            <div class="card-body">
              <p class="card-text text-center">동영상 ID: {{ videoId }}</p>
            </div>
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>