from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.
class User(AbstractUser):
    # 여기는 그냥 받아온거고 따로 설정해줄 거는 없다 
    pass
