-- 공통
SELECT * FROM articles;
DROP TABLE articles;
PRAGMA table_info('articles');


-- 1. Insert data into table


-- 2. Update data in table


-- 3. Delete data from table
