from django.apps import AppConfig


class ContentfetchConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'contentfetch'
